﻿namespace ProjectManagerAPI.Data.Enum
{
	public enum ProjectStatus
	{
		INWORK =0,
		FINISHED =1,
	}
}
