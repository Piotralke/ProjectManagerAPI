﻿namespace ProjectManagerAPI.Data.Enum
{
	public enum EventType
	{
		TASK=0,
		EVENT=1,
		Default
	}
}
