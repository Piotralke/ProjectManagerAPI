﻿namespace ProjectManagerAPI.Data.Enum
{
	public enum Role
	{
		ADMIN,		//0
		STUDENT,	//1
		TEACHER		//2
	}
}
