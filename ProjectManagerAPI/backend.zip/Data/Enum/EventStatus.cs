﻿namespace ProjectManagerAPI.Data.Enum
{
	public enum EventStatus
	{
		PLANNED,
		STARTED,
		FINISHED
	}
}
