﻿namespace ProjectManagerAPI.Data.Enum
{
	public enum ProposalState
	{
		SENT=0,
		ACCEPTED=1,
		REJECTED=2,
		EDITED=3
	}
}
